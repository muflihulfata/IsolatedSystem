# Before v22
rm -rf /data/misc/riru/modules/isolatedsystem

# After v22
rm -rf /data/adb/riru/modules/isolatedsystem

rm -rf /data/adb/isolatedsystem/